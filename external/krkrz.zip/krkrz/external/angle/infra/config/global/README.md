## Global configs.

**IMPORTANT:** If you see this in a branch which is not `master`,
**this directory has no effect and should be ignored.**

This branch contains ANGLE project-wide configurations
for chrome-infra services.
For example, [cr-buildbucket.cfg](cr-buildbucket.cfg) defines builders.

**Remember** Change these configs on `master` branch only!

Currently active version can be checked at
https://luci-config.appspot.com/#/projects/angle .

