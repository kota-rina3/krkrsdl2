
#include "tjsCommHead.h"
#include "NativeEventQueue.h"


void NativeEventQueueImplement::HandlerDefault( NativeEvent& event ) {
}
void NativeEventQueueImplement::Allocate() {
}
void NativeEventQueueImplement::Deallocate() {
}
void NativeEventQueueImplement::PostEvent( const NativeEvent& event ) {
}

