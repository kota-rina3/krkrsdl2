
#include "tjsCommHead.h"
#include "TouchPoint.h"

const double TouchPointList::SCALE_THRESHOLD = 5;
const double TouchPointList::ROTATE_THRESHOLD = 5;

